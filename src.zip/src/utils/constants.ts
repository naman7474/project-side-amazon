export const DefaultPaginationLimit = 500;

export const USER_STORAGE_KEY = "user";

export const TEMP = 1;
