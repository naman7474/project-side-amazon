export { default as FormHolder } from "./form-holder";

export { default as UploadForm } from "./form-upload";
export { default as SlugForm } from "./form-slug";
