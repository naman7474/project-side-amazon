export { default as AmazonOauthView } from "./amazon-oauth-view";
