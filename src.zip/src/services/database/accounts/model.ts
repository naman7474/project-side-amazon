export type User = {
  id: number;
  accessToken: string;
  password: string;
  email: string;
  phone: string;
  name: string;
  imageUrl: string;
  company: string;
  gst: string;
};
