export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME;

export const HOST_API = process.env.NEXT_PUBLIC_HOST_API;
