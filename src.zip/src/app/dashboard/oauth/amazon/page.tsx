import { AmazonOauthView } from "@/sections/amazon";

export default function AmazonOauthPage() {
  return <AmazonOauthView />;
}
